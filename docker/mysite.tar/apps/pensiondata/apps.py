from django.apps import AppConfig


class PensiondataConfig(AppConfig):
    name = 'pensiondata'
