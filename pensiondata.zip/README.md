
Elastic Beanstalk Docker template for Django
============================================

Tutorial (Part 2): http://glynjackson.org/weblog/django-aws-elastic-beanstalk-docker-2/
Boilerplate Docker template for Django 1.9+ running Python 3.4.+ on AWS's Elastic Beanstalk.

Part 1: http://glynjackson.org/weblog/tutorial-deploying-django-app-aws-elastic-beanstalk-using-docker/

Starting your project
---------------------

Run the following command::

    $ django-admin.py startproject --template=https://github.com/glynjackson/django-docker-template2/zipball/master mysite
    