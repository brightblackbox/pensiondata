default_app_config = 'pensiondata.apps.PensiondataConfig'
